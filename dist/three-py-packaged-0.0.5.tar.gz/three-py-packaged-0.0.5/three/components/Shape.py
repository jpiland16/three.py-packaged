from three.components import *
#Shape, a type of component that is exactly what it sounds like, a shape
class Shape(Component):
    def __init__(self):
        super().__init__()

    def intersectSphere(self,other):
        pass

from three.lights.Light import *
from three.lights.AmbientLight import *
from three.lights.DirectionalLight import *
from three.lights.PointLight import *

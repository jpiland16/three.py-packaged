from three.physics.ComponentMesh import *

from three.components.Component import *

from three.components.Shape import *

from three.components.Sphere import *

from three.components.Plane import *

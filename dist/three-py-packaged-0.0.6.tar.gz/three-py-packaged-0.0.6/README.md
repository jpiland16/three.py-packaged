three-py-packaged
=================

This project serves as a `pip`-installable version of `three.py` created by Dr. Lee Stemkoski. His original source code can be found [here](https://github.com/stemkoski/three.py).

This project uses the MIT license.